function data = headerIgnoreCSVRead( fileName, numIgnore )
%headerIgnoreCSVRead Summary of this function goes here
%   Detailed explanation goes here

fileID = fopen( fileName );

% For normal files, there are 18 lines of header
if nargin == 1
    numIgnore = 18;
end

% Get to below the header
for i = 1:numIgnore
    fgetl(fileID);
end

% Copy everything that is below the header
buffer = fread(fileID, Inf);
fclose(fileID);

% Write it to a file
fileID = fopen('temp.csv','w+');
fwrite(fileID, buffer);
fclose(fileID);

% Reimport it with csv read and delete temporary file
data = csvread('temp.csv');
delete('temp.csv');

end

